-- Copyright 2008 Steven Barth <steven@midlink.org>
-- Copyright 2008 Jo-Philipp Wich <jow@openwrt.org>
-- Licensed to the public under the Apache License 2.0.

module("luci.controller.ipsec", package.seeall)

function index()
    local uci = require("luci.model.uci").cursor()
    local page

    page = node("admin", "ipsec")
    page.target = firstchild()
    page.title  = _("IPSec")
    page.order  = 70
    page.index  = true

    page = entry({"admin", "ipsec", "overview"}, arcombine(cbi("ipsec/overview"), cbi("ipsec/conn")), _("Overview"), 1)
    page.leaf   = true
    page.subindex = true

    page = entry({"admin", "ipsec", "conn_add"}, cbi("ipsec/conn_add"), nil)
    page.leaf = true

    page = entry({"admin", "ipsec", "conn_stop"}, call("conn_stop"), nil)
    page.leaf   = true

    page = entry({"admin", "ipsec", "conn_start"}, call("conn_start"), nil)
    page.leaf   = true

    page = entry({"admin", "ipsec", "conn_del"}, call("conn_del"), nil)
    page.leaf = true

    page = entry({"admin", "ipsec", "config"}, call("config_update"), translate("Import/Export"))

    uci:foreach("ipsec", "conn",
        function (section)
            local conname = section[".name"]
                entry({"admin", "ipsec", "overview", conname},true, conname:upper())
        end)
end

function conn_start(conn)
    luci.sys.exec("ipsec down " .. conn)
    luci.sys.exec("ipsec up " .. conn)
    luci.http.redirect(luci.dispatcher.build_url("admin/ipsec/overview") .. "?action=reconnect")
end

function conn_stop(conn)
    luci.sys.exec("ipsec down " .. conn)
    luci.http.redirect(luci.dispatcher.build_url("admin/ipsec/overview") .. "?action=stop")
end

function conn_del(conn)
    local uci = require("luci.model.uci").cursor()
    uci:delete_all("ipsec","conn",
        function(s) return s['.name'] == conn end)

    uci:commit("ipsec")
    luci.sys.exec("/etc/init.d/ipsec reload")
    luci.http.redirect(luci.dispatcher.build_url("admin/ipsec/overview") .. "?action=delete")
    return 
end


function config_update()
    local fp
    local upload_config_path
    local upload_name_check = true
	local backup_cmd = "echo ipsec.json > /tmp/backup; tar -czf - -C /tmp/sdconfig/ -T /tmp/backup"

    luci.http.setfilehandler(
        function(meta, chunk, eof)
            if not meta then return end
            if not meta.file or not string.match(meta.file , "%.tar%.gz$") then
                upload_name_check = false
                return
            end
            upload_config_path = "/tmp/" .. meta.file
            luci.sys.exec("echo " .. upload_config_path .. " > /tmp/sdconfname" )
            if not fp then
                fp = io.open(upload_config_path, "w")
            end
            if chunk then
                fp:write(chunk)
            end
            if eof then
                fp:close()
            end
        end
    )

    if luci.http.formvalue("backup") then
        local checkret = luci.sys.exec("/usr/sbin/sdconfig ipsec backup")
        if string.match(checkret,"sdconfig success") then
            local reader = ltn12_popen(backup_cmd)
            luci.http.header('Content-Disposition', 'attachment; filename="backup-ipsec-%s-%s.tar.gz"' % {
                    luci.sys.hostname(), os.date("%Y-%m-%d")})
            luci.http.prepare_content("application/x-targz")
            luci.ltn12.pump.all(reader, luci.http.write)
        else            
            luci.template.render("ipsec/config_update", 
                {
                    check_fail = "Create ipsec backup fail"
                })
        end
    elseif luci.http.formvalue("restore") then
        if upload_name_check == false then
            luci.template.render("ipsec/config_update", 
                {
                    check_fail = "Format of upload file not supported"
                })
       else
            local upload = luci.http.formvalue("archive")
            if upload and #upload > 0 then
                local checkret = luci.sys.exec("/usr/sbin/sdconfig ipsec check " .. upload_config_path)
                if string.match(checkret,"sdconfig success") then
                    luci.template.render("ipsec/config_update", 
                        {
                            check_success = true
                        })
                else
                    luci.template.render("ipsec/config_update", 
                        {
                            check_fail = "Errors with upload file, see syslog for more details"
                        })
                end
            else
                luci.template.render("ipsec/config_update", {})
            end
        end
    elseif luci.http.formvalue("cancel") then
        luci.template.render("ipsec/config_update", {})
    elseif luci.http.formvalue("apply") then
        local sdconfig = luci.sys.exec("cat /tmp/sdconfname 2>/dev/null")
        if sdconfig and #sdconfig > 0 then
            luci.sys.exec("/usr/sbin/sdconfig ipsec update " .. sdconfig)
            luci.sys.exec("rm -f /tmp/sdconfname 2>/dev/null")
            luci.template.render("ipsec/config_update",
                {
                    config_applying = true
                })
        else
            luci.template.render("ipsec/config_update",
                {
                    check_fail = "config update fail"
                })
        end
    else
        luci.template.render("ipsec/config_update", {})
    end

end
function ltn12_popen(command)
    local fdi, fdo = nixio.pipe()
    local pid = nixio.fork()

    if pid > 0 then
        fdo:close()
        local close
        return function()
            local buffer = fdi:read(2048)
            local wpid, stat = nixio.waitpid(pid, "nohang")
            if not close and wpid and stat == "exited" then
                close = true
            end

            if buffer and #buffer > 0 then
                return buffer
            elseif close then
                fdi:close()
                return nil
            end
        end
    elseif pid == 0 then
        nixio.dup(fdo, nixio.stdout)
        fdi:close()
        fdo:close()
        nixio.exec("/bin/sh", "-c", command)
    end
end
