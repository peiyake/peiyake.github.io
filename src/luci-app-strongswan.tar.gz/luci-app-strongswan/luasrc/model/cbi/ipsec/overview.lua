-- Copyright 2008 Steven Barth <steven@midlink.org>
-- Licensed to the public under the Apache License 2.0.

--local m = Map("ipsec", translate("IPSec Instances Overview"))
local m = Map("ipsec")

local p = m:section( SimpleSection )
p.template = "ipsec/pageswitch"
p.mode     = "overview"

m.pageaction = false
m:section(SimpleSection).template = "ipsec/overview"
--[[

local s = m:section( TypedSection, "conn", translate("strongSwan instances"), translate("Below is a list of configured strongSwan instances and their current state") )
s.template = "cbi/tblsection"
s.template_addremove = "strongswan/cbi-select-input-add"
s.addremove = true
s.extedit = luci.dispatcher.build_url(
	"admin", "services", "strongswan", "basic", "%s"
)

function s.create(self, name)
	name = luci.http.formvalue(
		luci.cbi.CREATE_PREFIX .. self.config .. "." ..
		self.sectiontype .. ".text"
	)
	if string.len(name)>3 and not name:match("[^a-zA-Z0-9_]") then
		--uci:section("strongswan", "conn", name,uci:get_all( "strongswan", "global" ))
		uci:section("strongswan", "conn")
		uci:section("strongswan", "ike")
		uci:section("strongswan", "ipsec")

		--uci:delete("openvpn", name, "_description")
		uci:save("strongswan")

		luci.http.redirect( self.extedit:format(name) )
	else
		self.invalid_cts = true
	end
end



s:option( Flag, "enabled", translate("Enabled") )

local active = s:option( DummyValue, "_active", translate("Started") )
function active.cfgvalue(self, section)
	local pid = sys.exec("%s | grep %s | grep openvpn | grep -v grep | awk '{print $1}'" % { psstring,section} )
	if pid and #pid > 0 and tonumber(pid) ~= nil then
		return (sys.process.signal(pid, 0))
			and translatef("yes (%i)", pid)
			or  translate("no")
	end
	return translate("no")
end

local updown = s:option( Button, "_updown", translate("Start/Stop") )
updown._state = false
updown.redirect = luci.dispatcher.build_url(
	"admin", "services", "openvpn"
)
function updown.cbid(self, section)
	local pid = sys.exec("%s | grep %s | grep openvpn | grep -v grep | awk '{print $1}'" % { psstring,section} )
	self._state = pid and #pid > 0 and sys.process.signal(pid, 0)
	self.option = self._state and "stop" or "start"
	return AbstractValue.cbid(self, section)
end
function updown.cfgvalue(self, section)
	self.title = self._state and "stop" or "start"
	self.inputstyle = self._state and "reset" or "reload"
end
function updown.write(self, section, value)
	if self.option == "stop" then
		local pid = sys.exec("%s | grep %s | grep openvpn | grep -v grep | awk '{print $1}'" % { psstring,section} )
		sys.process.signal(pid,15)
	else
		luci.sys.call("/etc/init.d/openvpn start %s" % section)
	end
	luci.http.redirect( self.redirect )
end


local port = s:option( DummyValue, "left", translate("Local Ipaddress") )
function port.cfgvalue(self, section)
	local val = AbstractValue.cfgvalue(self, section)
	return val or "%any"
end

local proto = s:option( DummyValue, "right", translate("Remote Ipaddress") )
function proto.cfgvalue(self, section)
	local val = AbstractValue.cfgvalue(self, section)
	return val or "%any"
end

]]
return m
