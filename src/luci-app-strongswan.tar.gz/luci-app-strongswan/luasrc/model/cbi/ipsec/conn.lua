
require("luci.ip")
require("luci.model.uci")
local datatypes  = require("luci.cbi.datatypes")

arg[1] = arg[1] or ""

--local m = Map("ipsec",translate("IPSec Connection Setup"))
local m = Map("ipsec")
m.redirect = luci.dispatcher.build_url("admin", "ipsec", "overview")

local p = m:section( SimpleSection )
p.template = "ipsec/pageswitch"
p.mode     = "conn"
p.instance = arg[1]

local con = m:section(NamedSection, arg[1], "conn",translate("IPSec server setting"))

local left = con:option(Value , "left", translate("left"),translate("default value is the ipaddress of the default route device"))
left.datatype = "ip4addr"
left.default = "0.0.0.0"

local right = con:option(Value , "right", translate("right"))
right.datatype = "ip4addr"
right.rmempty = false

local pingaddress = con:option(Value , "pingaddress", translate("ping address"))
pingaddress.datatype = "ip4addr"
left.default = "0.0.0.0"

local pingenable = con:option(Value , "pingenable", translate("ping enable"))
pingenable:value("true",translate("Enable"))
pingenable:value("false",translate("Disable"))
pingenable.default = "true"

local reqid = con:option(Value , "reqid", translate("reqid"))
reqid.datatype = "range(1,65535)"
reqid.rmempty = false
reqid.default = "1"

--local rightsubnet = con:option(DynamicList , "rightsubnet", translate("rightsubnet"))
--rightsubnet.datatype = "ip4addr"
--rightsubnet.placeholder = "0.0.0.0/0"
--rightsubnet:depends("keyexchange","ikev1")
--rightsubnet:depends("keyexchange","v1")

function check_subnet(value)
    local regip1 = "^%d+%.%d+%.%d+%.%d+$"
    local regip2 = "^%d+%.%d+%.%d+%.%d+/[0-9]$"
    local regip3 = "^%d+%.%d+%.%d+%.%d+/[0-2][0-9]$"
    local regip4 = "^%d+%.%d+%.%d+%.%d+/3[0-2]$"
    local reg1 = "^%d+%.%d+%.%d+%.%d+%[.+/.+%]$"
    local reg2 = "^%d+%.%d+%.%d+%.%d+/[0-9]%[.+/.+%]$"
    local reg3 = "^%d+%.%d+%.%d+%.%d+/[0-2][0-9]%[.+/.+%]$"
    local reg4 = "^%d+%.%d+%.%d+%.%d+/3[0-2]%[.+/.+%]$"
    local regnum = "(%d+)[%./]"

    if  not string.match(value,regip1) and   
        not string.match(value,regip2) and   
        not string.match(value,regip3) and   
        not string.match(value,regip4) and   
        not string.match(value,reg1) and  
        not string.match(value,reg2) and  
        not string.match(value,reg3) and  
        not string.match(value,reg4)     

    then
        return false
    end

    for num in string.gmatch(value,regnum) do
        local n = tonumber(num)
        if n == nil or n > 255 then
            return false
        end
    end
    return true
end

local leftsubnet = con:option(DynamicList , "leftsubnet", translate("leftsubnet"),
                translate("attention: IKEv2 supports multiple subnets , IKEv1 only interprets the first subnet"))
leftsubnet.placeholder = "0.0.0.0/0"
leftsubnet.datatype = "string"
function leftsubnet.validate(self, value,section)
    if not value or #value == 0 then
        esp:add_error(section, translate("leftsubnet not given!"))
    end
    local errmsg = ""
    local err = false
    if type(value) == "table" then
        local x
        for _, x in ipairs(value) do
            if x and #x > 0 then
                if not check_subnet(x) then
                    err  = true
                    errmsg = x .. " " .. errmsg
                end
            end
        end
    else
        if not check_subnet(value) then
            err  = true
            errmsg = value
        end
    end
    if err then
        leftsubnet:add_error(section, translate(errmsg .. "  not support ipsec subnet style!"))
    end
    return value
end

local rightsubnet = con:option(DynamicList , "rightsubnet", translate("rightsubnet"),
                translate("attention: IKEv2 supports multiple subnets , IKEv1 only interprets the first subnet"))
rightsubnet.placeholder = "0.0.0.0/0"
rightsubnet.datatype = "string"
function rightsubnet.validate(self, value,section)
    if not value or #value == 0 then
        esp:add_error(section, translate("rightsubnet not given!"))
    end
    local errmsg = ""
    local err = false
    if type(value) == "table" then
        local x
        for _, x in ipairs(value) do
            if x and #x > 0 then
                if not check_subnet(x) then
                    err  = true
                    errmsg = x .. " " .. errmsg
                end
            end
        end
    else
        if not check_subnet(value) then
            err  = true
            errmsg = value
        end
    end
    if err then
        rightsubnet:add_error(section, translate(errmsg .. "  not support ipsec subnet style!"))
    end
    return value
end
local auto = con:option(ListValue, "auto", translate("Ipsec startup mode"),translate("what operation,should be done automatically at IPsec startup."))
auto:value("route",translate("route"))
auto:value("ignore",translate("ignore"))
auto:value("add",translate("add"))
auto:value("start",translate("start"))
auto.default = "route"

local crtfile = con:option(Value, "crtfile", translate("crtfile"))
crtfile.default = "local.crt"


local s = m:section( NamedSection, "default", "global",translate("Global parameter settings"))

s:tab("general",  translate("General Setup"))
s:tab("authmode",  translate("Authentication Setup"))
s:tab("advanced", translate("Advanced Settings"))

local ike_version = s:taboption("general",ListValue, "keyexchange", translate("IKE version"))
ike_version.widget = "radio"
ike_version:value("ikev1",translate("v1"))
ike_version:value("ikev2",translate("v2"))
ike_version:value("ike",translate("auto"))
ike_version.default = "ikev1"
ike_version.orientation = "horizontal"

function check_algorithm(value)
    local reg1 = "^%w+-%w+!?$"
    local reg2 = "^%w+-%w+-%w+!?$"

    if not string.match(value,reg1) and not string.match(value,reg2) then
        return false
    end
    return true
end

local esp = s:taboption("general",DynamicList , "esp", translate("ESP algorithm"),
                translate("attention: For IKEv2, multiple algorithms can be included in a single proposal; IKEv1 only includes the first algorithm in a proposal"))
esp.datatype = "string"
esp.placeholder = "aes128-sha1!"
function esp.validate(self, value,section)
    if not value or #value == 0 then
        esp:add_error(section, translate("algorithm not given!"))
    end
    local errmsg = ""
    local err = false
    if type(value) == "table" then
        local x
        for _, x in ipairs(value) do
            if x and #x > 0 then
                if not check_algorithm(x) then
                    err  = true
                    errmsg = x .. " " .. errmsg
                end
            end
        end
    else
        if not check_algorithm(value) then
            err  = true
            errmsg = value
        end

    end
    if err then
        esp:add_error(section, translate(errmsg .. "  not support"))
    end
    return value
end

local ike = s:taboption("general",DynamicList , "ike", translate("IKE algorithm"),
                    translate("attention: For IKEv2, multiple algorithms can be included in a single proposal; IKEv1 only includes the first algorithm in a proposal"))
ike.datatype = "string"
ike.placeholder = "3des-sha-modp1024!"
function ike.validate(self, value,section)
    if not value or #value == 0 then
        ike:add_error(section, translate("algorithm not given!"))
    end
    local errmsg = ""
    local err = false
    if type(value) == "table" then
        local x
        for _, x in ipairs(value) do
            if x and #x > 0 then
                if not check_algorithm(x) then
                    err  = true
                    errmsg = x .. " " .. errmsg
                end
            end
        end
    else
        if not check_algorithm(value) then
            err  = true
            errmsg = value
        end

    end
    if err then
        ike:add_error(section, translate(errmsg .. "  not support"))
    end
    return value
end

--local leftsubnet = s:taboption("general",DynamicList , "leftsubnet", translate("leftsubnet"))
--leftsubnet.datatype = "ip4addr"
--leftsubnet.placeholder = "0.0.0.0/0"
--leftsubnet.rmempty = true



local auto = s:taboption("general",ListValue, "auto", translate("Ipsec startup mode"),
                        translate("what operation,should be done automatically at IPsec startup."))
auto:value("route",translate("route"))
auto:value("ignore",translate("ignore"))
auto:value("add",translate("add"))
auto:value("start",translate("start"))
auto.default = "route"

local leftfirewall = s:taboption("general",ListValue, "leftfirewall", translate("Left firewall"))
leftfirewall:value("yes",translate("yes"))
leftfirewall:value("no",translate("no"))
leftfirewall.default = "no"

local installpolicy = s:taboption("general",ListValue,"installpolicy",translate("installpolicy"),
                                translate("decides whether IPsec policies are installed in the kernel by the charon daemon for a given connection."))
installpolicy:value("yes",translate("yes"))
installpolicy:value("no",translate("no"))
installpolicy.default = "no"

local proto = s:taboption("authmode",ListValue,"proto",translate("Security protocol"))
proto:value("esp",translate("ESP"))
proto.default = "esp"

local authby = s:taboption("authmode",ListValue, "authby", translate("Authentication mode"))
authby:value("psk",translate("pre-shared key"))
authby:value("rsasig",translate("rsasig"))
authby:value("pubkey",translate("pubkey"))
authby.default = "rsasig"

local secretkey = s:taboption("authmode",Value, "secretkey", translate("Pre-shared key"))
secretkey:depends("authby","psk")
secretkey.password=true

local leftcert = s:taboption("authmode",Value, "leftcert", translate("leftcerte"))
leftcert:depends("authby","rsasig")
leftcert:depends("authby","pubkey")
leftcert.default = "local.crt"

local leftsendcert = s:taboption("authmode",ListValue, "leftsendcert", translate("leftsendcertt"))
leftsendcert:value("never",translate("never"))
leftsendcert:value("no",translate("no"))
leftsendcert:value("ifasked",translate("ifasked"))
leftsendcert:value("always",translate("always"))
leftsendcert:value("yes",translate("yes"))
leftsendcert.default = "always"

local lefthostaccess = s:taboption("authmode",Value, "lefthostaccess", translate("lefthostaccess"))
lefthostaccess:value("yes","yes")
lefthostaccess:value("no","no")
lefthostaccess.default = "yes"



local type = s:taboption("authmode",ListValue, "type", translate("Type"))
--type.widget = "radio"
type:value("transport",translate("Transport Modle"))
type:value("tunnel",translate("Tunnel Modle"))
type.default = "tunnel"
--type.orientation = "horizontal"

local ikelifetime = s:taboption("advanced",Value,"ikelifetime",translate("ikelifetime"),translate("hour"))
ikelifetime.datatype = "uinteger"
ikelifetime.default = "24"

local keylife = s:taboption("advanced",Value,"keylife",translate("keylife"),translate("minute"))
keylife.datatype = "uinteger"
keylife.default = "75"

local rekeymargin = s:taboption("advanced",Value,"rekeymargin",translate("rekeymargin"),translate("minute"))
rekeymargin.datatype = "uinteger"
rekeymargin.default = "10"

local keyingtries = s:taboption("advanced",Value,"keyingtries",translate("keyingtries"))
keyingtries.datatype = "uinteger"
keyingtries.default = "1"

local rekey = s:taboption("advanced",ListValue,"rekey",translate("rekey"))
rekey:value("yes",translate("yes"))
rekey.default = "yes"

local rekeyfuzz = s:taboption("advanced",Value,"rekeyfuzz",translate("rekeyfuzz"),translate("%"))
rekeyfuzz.datatype = "range(0,100)"
rekeyfuzz.default = "100"

local dpdaction = s:taboption("advanced",ListValue,"dpdaction",translate("dpdaction"),
                                translate("controls the use of the Dead Peer Detection protocol (DPD, RFC 3706) where R_U_THERE notification messages   \
                                (IKEv1) or empty INFORMATIONAL messages (IKEv2) are periodically sent in order to check the liveliness of the IPsec peer"))
dpdaction:value("none",translate("none"))
dpdaction:value("clear",translate("clear"))
dpdaction:value("hold",translate("hold"))
dpdaction:value("restart",translate("restart"))
dpdaction.default = "none"

local closeaction = s:taboption("advanced",ListValue,"closeaction",translate("closeaction"),
                                translate("defines the action to take if the remote peer unexpectedly closes a CHILD_SA"))
closeaction:value("none",translate("none"))
closeaction:value("clear",translate("clear"))
closeaction:value("hold",translate("hold"))
closeaction:value("restart",translate("restart"))
closeaction.default = "restart"

local compress = s:taboption("advanced",ListValue,"compress",translate("compress"),
                                translate("whether IPComp compression of content is proposed on the connection"))
compress:value("yes",translate("yes"))
compress:value("no",translate("no"))
compress.default = "no"





return m