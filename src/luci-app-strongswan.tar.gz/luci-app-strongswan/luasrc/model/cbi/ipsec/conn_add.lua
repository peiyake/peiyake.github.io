local utl = require "luci.util"
local uci = require "luci.model.uci".cursor()

m = SimpleForm("ipsec", translate("Create new IPSec connection"))
m.redirect = luci.dispatcher.build_url("admin/ipsec/overview")
m.reset = false

local conn = m:field(Value, "connection", translate("Name of the new connection"),
	translate("The allowed characters are: <code>A-Z</code>, <code>a-z</code>, " ..
		"<code>0-9</code> and <code>_</code>"
	))

conn.datatype = "and(uciname,rangelength(1,15))"

local type = m:field(ListValue, "type", translate("Type"))
type:value("tunnel",translate("Tunnel Modle"))
type.default = "tunnel"

function conn_exist(name)
    local ret = false
    uci:foreach("ipsec","conn",function(s)
        if name == s.name then
            ret = true
        end
    end)

    if ret == true then
        return true
    else
        return false
    end
end

function type.validate(self, value, section)
	local name = conn:formvalue(section)
	if not name or #name == 0 then
		conn:add_error(section, translate("No connection name specified"))
	else 
        local exist = conn_exist(name)
        if exist == true then
		    conn:add_error(section, translate("The given connection name is not unique"))
        end
	end
	return value
end

function type.write(self, section, value)
	local name = conn:formvalue(section)
	if name and #name > 0 then
        uci:section("ipsec","global","default")
        uci:section("ipsec","conn",name)

        uci:save("ipsec")
		luci.http.redirect(luci.dispatcher.build_url("admin/ipsec/overview", name))
	end
end

return m